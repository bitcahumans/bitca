docker run -d \
 -p 9042:9042 cassandra:latest \
 --name cassandra-db